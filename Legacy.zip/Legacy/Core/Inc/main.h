/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define USART10_RX_SPI4_SCK_Pin GPIO_PIN_2
#define USART10_RX_SPI4_SCK_GPIO_Port GPIOE
#define POWER24V_OUT2_Pin GPIO_PIN_13
#define POWER24V_OUT2_GPIO_Port GPIOC
#define POWER24V_OUT1_Pin GPIO_PIN_14
#define POWER24V_OUT1_GPIO_Port GPIOC
#define POWER5V_OUT_Pin GPIO_PIN_15
#define POWER5V_OUT_GPIO_Port GPIOC
#define ACELROM_CS_Pin GPIO_PIN_0
#define ACELROM_CS_GPIO_Port GPIOC
#define GYRO_CS_Pin GPIO_PIN_3
#define GYRO_CS_GPIO_Port GPIOC
#define TIM2_CH1_Servo_Pin GPIO_PIN_0
#define TIM2_CH1_Servo_GPIO_Port GPIOA
#define OCTOSPIM_P1_IO3_Flash_Pin GPIO_PIN_1
#define OCTOSPIM_P1_IO3_Flash_GPIO_Port GPIOA
#define TIM2_CH3_Servo_Pin GPIO_PIN_2
#define TIM2_CH3_Servo_GPIO_Port GPIOA
#define OCTOSPIM_P1_IO2_Flash_Pin GPIO_PIN_3
#define OCTOSPIM_P1_IO2_Flash_GPIO_Port GPIOA
#define GPIO_RESERVED_Pin GPIO_PIN_4
#define GPIO_RESERVED_GPIO_Port GPIOA
#define GPIO_RESERVEDA5_Pin GPIO_PIN_5
#define GPIO_RESERVEDA5_GPIO_Port GPIOA
#define GPIO_RESERVEDA6_Pin GPIO_PIN_6
#define GPIO_RESERVEDA6_GPIO_Port GPIOA
#define ADC1_4_VBAT_SENSE_Pin GPIO_PIN_4
#define ADC1_4_VBAT_SENSE_GPIO_Port GPIOC
#define DBG_BTN2_Pin GPIO_PIN_5
#define DBG_BTN2_GPIO_Port GPIOC
#define DBG_BTN2_EXTI_IRQn EXTI9_5_IRQn
#define OCTOSPIM_P1_IO1_Flash_Pin GPIO_PIN_0
#define OCTOSPIM_P1_IO1_Flash_GPIO_Port GPIOB
#define TIM3_CH4_IMU_HEATING_Pin GPIO_PIN_1
#define TIM3_CH4_IMU_HEATING_GPIO_Port GPIOB
#define OCTOSPIM_P1_CLK_Flash_Pin GPIO_PIN_2
#define OCTOSPIM_P1_CLK_Flash_GPIO_Port GPIOB
#define TIM1_CH1_Servo_Pin GPIO_PIN_9
#define TIM1_CH1_Servo_GPIO_Port GPIOE
#define ACELROM_IRQ_Pin GPIO_PIN_10
#define ACELROM_IRQ_GPIO_Port GPIOE
#define ACELROM_IRQ_EXTI_IRQn EXTI15_10_IRQn
#define OCTOSPIM_P1_NCS_Flash_Pin GPIO_PIN_11
#define OCTOSPIM_P1_NCS_Flash_GPIO_Port GPIOE
#define GYRO_IRQ_Pin GPIO_PIN_12
#define GYRO_IRQ_GPIO_Port GPIOE
#define GYRO_IRQ_EXTI_IRQn EXTI15_10_IRQn
#define TIM1_CH3_Servo_Pin GPIO_PIN_13
#define TIM1_CH3_Servo_GPIO_Port GPIOE
#define GPIO_RESERVED_WS2812_Pin GPIO_PIN_14
#define GPIO_RESERVED_WS2812_GPIO_Port GPIOE
#define SP1_CS_RESERVED_Pin GPIO_PIN_15
#define SP1_CS_RESERVED_GPIO_Port GPIOE
#define I2C2_SCL_RESERVED_Pin GPIO_PIN_10
#define I2C2_SCL_RESERVED_GPIO_Port GPIOB
#define I2C2_SDA_RESERVED_Pin GPIO_PIN_11
#define I2C2_SDA_RESERVED_GPIO_Port GPIOB
#define GPIO_RESERVEDB12_Pin GPIO_PIN_12
#define GPIO_RESERVEDB12_GPIO_Port GPIOB
#define RS485_USART3_DE_Pin GPIO_PIN_14
#define RS485_USART3_DE_GPIO_Port GPIOB
#define TIM12_CH2_BUZZER_Pin GPIO_PIN_15
#define TIM12_CH2_BUZZER_GPIO_Port GPIOB
#define RS485_USART3_TX_Pin GPIO_PIN_8
#define RS485_USART3_TX_GPIO_Port GPIOD
#define RS485_USART3_RX_Pin GPIO_PIN_9
#define RS485_USART3_RX_GPIO_Port GPIOD
#define GPIO_RESERVEDD10_Pin GPIO_PIN_10
#define GPIO_RESERVEDD10_GPIO_Port GPIOD
#define OCTOSPIM_P1_IO0_Flash_Pin GPIO_PIN_11
#define OCTOSPIM_P1_IO0_Flash_GPIO_Port GPIOD
#define TIM8_CH1_ENCODER_Pin GPIO_PIN_6
#define TIM8_CH1_ENCODER_GPIO_Port GPIOC
#define TIM8_CH2_ENCODER_Pin GPIO_PIN_7
#define TIM8_CH2_ENCODER_GPIO_Port GPIOC
#define IR_SENSE_Pin GPIO_PIN_8
#define IR_SENSE_GPIO_Port GPIOC
#define IR_SENSE_EXTI_IRQn EXTI9_5_IRQn
#define GPIO_RESERVEDA8_Pin GPIO_PIN_8
#define GPIO_RESERVEDA8_GPIO_Port GPIOA
#define DBG_BTN2A15_Pin GPIO_PIN_15
#define DBG_BTN2A15_GPIO_Port GPIOA
#define DBG_BTN2A15_EXTI_IRQn EXTI15_10_IRQn
#define UART5_RX_SBUS_Pin GPIO_PIN_2
#define UART5_RX_SBUS_GPIO_Port GPIOD
#define GPIO_RESERVEDD3_Pin GPIO_PIN_3
#define GPIO_RESERVEDD3_GPIO_Port GPIOD
#define RS485_USART2_DE_Pin GPIO_PIN_4
#define RS485_USART2_DE_GPIO_Port GPIOD
#define RS485_USART2_TX_Pin GPIO_PIN_5
#define RS485_USART2_TX_GPIO_Port GPIOD
#define RS485_USART2_RX_Pin GPIO_PIN_6
#define RS485_USART2_RX_GPIO_Port GPIOD
#define DBG_LED_Pin GPIO_PIN_7
#define DBG_LED_GPIO_Port GPIOB
#define GPIO_RESERVEDB8_Pin GPIO_PIN_8
#define GPIO_RESERVEDB8_GPIO_Port GPIOB
#define GPIO_RESERVEDB9_Pin GPIO_PIN_9
#define GPIO_RESERVEDB9_GPIO_Port GPIOB
#define GPIO_RESERVEDE0_Pin GPIO_PIN_0
#define GPIO_RESERVEDE0_GPIO_Port GPIOE
#define GPIO_RESERVEDE1_Pin GPIO_PIN_1
#define GPIO_RESERVEDE1_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
